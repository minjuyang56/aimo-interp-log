AIMO Interpretability Challenge - technical report, Overleaf-ready (ANONYMIZED)
==============================================================================
1. Upload aimo_interp_report.tex to a new Overleaf project (New Project -> Upload Project).
2. For the NeurIPS workshop style, add neurips_2026.sty and swap the two lines marked
   [NEURIPS] at the top of the .tex (article -> neurips_2026).
3. Compile with pdfLaTeX. Bibliography is inline (thebibliography) - no .bib needed.

PAGE BUDGET: the 5-page limit covers the abstract and Sections 1-7 only. Limitations, the
AI-usage statement, references and appendices are excluded. As built here that part is
exactly 5 pages; re-check it if you change the style file.

ANONYMITY: author block is "Anonymous Author(s)"; the code link points at
anonymous.4open.science. Before submitting, confirm the 4open.science slug resolves.

REMAINING PLACEHOLDERS (red TODO in the PDF), both need a human action:
 - the hfin submission_id, once that ZIP is uploaded to Codabench
 - the 4open.science slug, once the anonymized view is created
