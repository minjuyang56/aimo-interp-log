AIMO Interp Challenge - technical report, Overleaf-ready (ANONYMIZED)
====================================================================
1. Upload aimo_interp_report.tex to a new Overleaf project.
2. For the NeurIPS workshop style add neurips_2026.sty and swap the two [NEURIPS] lines.
3. pdfLaTeX. Bibliography is inline - no .bib needed.

PAGE BUDGET: the 5-page limit covers the abstract and Sections 1-7 only; limitations, the
AI-usage statement, references and appendices are excluded. As built: exactly 5 pages.

ANONYMITY: author is "Anonymous Author(s)"; code link is
https://anonymous.4open.science/r/aimo-interp-log-6A8E (verified serving files).

REMAINING PLACEHOLDER (red TODO): the nominated submission_id, from Codabench My Submissions.
